import { React } from "jimu-core";
import { AllWidgetSettingProps } from "jimu-for-builder";

export default function Setting(props: AllWidgetSettingProps<any>) {
  return <div>You can drop widgets inside this container.</div>;
}
